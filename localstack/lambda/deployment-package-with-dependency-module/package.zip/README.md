<h1>Lambda layers</h1>
<p>
In aws lambda, function code upload size is limited to 50MB. But lambda layers provide additional space.
</p>
<p>
In localstack, lambda layers are supported only in the pro version. The workaround is to include the layer code alongside the function code. This is possible because the localstack does not limit file upload size.
</p>
<h3>
The following process only works in the pro version of localstack.
</h3>
<h2>Create layer file and zip file</h2>
<p>
create a folder called python and create the layer file in the python folder. This folder structure is required by aws. 
</p>
<p>python/hello_layer.py</p>
<code>
<pre>
def util():
  print('Hello from the layer')
</pre>
</code>
<p>Create the zip file.</p>
<code>
<pre>
zip -r hello_layer.zip python
</pre>
</code>
