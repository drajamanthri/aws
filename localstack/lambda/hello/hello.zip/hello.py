def handler(event, context):
    print('hello')
    return 'hello'